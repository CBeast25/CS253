#include "Doc.h"
#include <cassert>
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main() {
    Doc d;
    cout << "Empty doc is created!" << "\n";

    return 0;
}

