#include <iostream>
using namespace std;

int main() {
	// How many CU students does it take to change a light bulb?
	cout << "Three. One to hold the light bulb, one to google how,\n"
	"and another to fall off the ladder\n";
	return 0;
}
